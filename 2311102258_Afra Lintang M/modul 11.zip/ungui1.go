package main

import (
	"fmt"
)

func main() {
	var n int
	fmt.Print("Masukkan jumlah anak kelinci: ")
	fmt.Scan(&n)

	if n <= 0 || n > 1000 {
		fmt.Println("Jumlah anak kelinci harus antara 1 dan 1000")
		return
	}

	BERAT := make([]float64, n)
	fmt.Printf("Masukkan berat dari %d anak kelinci:\n", n)
	for i := 0; i < n; i++ {
		fmt.Scan(&BERAT[i])
	}

	BERATTerkecil := BERAT[0]
	BERATTerbesar := BERAT[0]

	for i := 1; i < n; i++ {
		if BERAT[i] < BERATTerkecil {
			BERATTerkecil = BERAT[i]
		}
		if BERAT[i] > BERATTerbesar {
			BERATTerbesar = BERAT[i]
		}
	} 

	fmt.Printf("Berat terkecil adalah : %.2f\n", BERATTerkecil)
	fmt.Printf("Berat terbesar adalah : %.2f\n", BERATTerbesar)
}
