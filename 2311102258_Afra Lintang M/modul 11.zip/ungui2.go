package main

import (
	"fmt"
)

func main() {
	var x, y int
	fmt.Print("Masukkan jumlah ikan (x) dan jumlah ikan per wadah (y): ")
	fmt.Scan(&x, &y)

	if x <= 0 || y <= 0 || x > 1000 {
		fmt.Println("Masukan tidak valid. Pastikan x > 0, y > 0, dan x <= 1000.")
		return
	}

	var Berat [1000]float64

	fmt.Println("Masukkan berat ikan : ")
	for i := 0; i < x; i++ {
		fmt.Scan(&Berat[i])
	}

	var containerBerat []float64
	var BeratSekarang float64

	for i := 0; i < x; i++ {
		BeratSekarang += Berat[i]
		if (i+1)%y == 0 || i == x-1 {
			containerBerat = append(containerBerat, BeratSekarang)
			BeratSekarang = 0
		}
	}

	fmt.Println("Total berat ikan di setiap wadah adalah : ")
	for _, weight := range containerBerat {
		fmt.Printf("%.2f ", weight)
	}
	fmt.Println()

	BeratTotal := 0.0
	for _, weight := range containerBerat {
		BeratTotal += weight
	}
	averageWeight := BeratTotal / float64(len(containerBerat))

	fmt.Printf("Berat rata-rata ikan per wadah adalah : %.2f\n", averageWeight)
}
