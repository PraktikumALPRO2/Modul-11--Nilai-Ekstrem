package main

import (
	"fmt"
)

const maxBalita = 100

type arrBalita [maxBalita]float64

func HitungMINMAX(arrBerat arrBalita, n int, bMin, bMax *float64) {
	*bMin = arrBerat[0]
	*bMax = arrBerat[0]
	for i := 1; i < n; i++ {
		if arrBerat[i] < *bMin {
			*bMin = arrBerat[i]
		}
		if arrBerat[i] > *bMax {
			*bMax = arrBerat[i]
		}
	}
}

func RataRata(arrBerat arrBalita, n int) float64 {
	var total float64
	for i := 0; i < n; i++ {
		total += arrBerat[i]
	}
	return total / float64(n)
}

func main() {
	var n int
	var berat arrBalita
	var bMin, bMax float64

	fmt.Print("Masukkan jumlah balita : ")
	fmt.Scan(&n)

	if n <= 0 || n > maxBalita {
		fmt.Println("Jumlah balita harus antara 1 dan", maxBalita)
		return
	}

	fmt.Printf("Masukkan berat dari %d balita : \n", n)
	for i := 0; i < n; i++ {
		fmt.Scan(&berat[i])
	}

	HitungMINMAX(berat, n, &bMin, &bMax)
	RataRataBerat := RataRata(berat, n)

	fmt.Printf("Berat terkecil balita adalah : %.2f kg\n", bMin)
	fmt.Printf("Berat terbesar balita adalah : %.2f kg\n", bMax)
	fmt.Printf("Berat rata-rata balita adalah : %.2f kg\n", RataRataBerat)
}
