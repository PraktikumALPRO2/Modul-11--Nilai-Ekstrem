package main

import "fmt"

func main() {
    var banyak int
    var beratKelinci [1000]float64
    var terkecil, terbesar float64

    fmt.Print("Masukkan Banyaknya Kelinci : ")
    fmt.Scan(&banyak)

    for i := 0; i < banyak; i++ {
        fmt.Printf("berat Kelinci %d : ", i+1)
        fmt.Scan(&beratKelinci[i])
    }

    terkecil = beratKelinci[0]
    terbesar = beratKelinci[0]
    for i := 1; i < banyak; i++ {
        if terbesar < beratKelinci[i] {
            terbesar = beratKelinci[i]
        }

        if terkecil > beratKelinci[i] {
            terkecil = beratKelinci[i]
        }
    }

    fmt.Println("Kelinci Terbesar : ", terbesar)
    fmt.Println("Kelinci Terkecil : ", terkecil)
}