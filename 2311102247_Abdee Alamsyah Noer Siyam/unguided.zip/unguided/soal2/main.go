package main

import (
    "fmt"
)

func validasi(x, y int) bool {
    return x > 0 && y > 0
}

func inputBerat(x int) []float64 {
    berat := make([]float64, x)
    for i := 0; i < x; i++ {
        fmt.Printf("Berat ikan ke-%d : ", i+1)
        fmt.Scan(&berat[i])
    }
    return berat
}

func hitungBerat(berat []float64, x, y int) {
    fmt.Println("\nTotal Berat dan Rata Rata :")
    for i := 0; i < x; i += y {
        end := i + y
        if end > x {
            end = x
        }

        var total float64
        for j := i; j < end; j++ {
            total += berat[j]
        }
        count := end - i
        fmt.Printf("Wadah %d \n", (i/y)+1)
        fmt.Printf("Total berat : %.2f \n", total)
        fmt.Printf("Rata Rata : %.2f \n", total/float64(count))
        fmt.Print("\n")
    }
}

func main() {
    var x, y int

    fmt.Print("Masukkan jumlah ikan yang dijual (x) : ")
    fmt.Scan(&x)
    fmt.Print("Masukkan jumlah ikan per wadah (y) : ")
    fmt.Scan(&y)

    if !validasi(x, y) {
        fmt.Println("Jumlah ikan dan kapasitas wadah harus lebih dari 0.")
        return
    }

    berat := inputBerat(x)
    hitungBerat(berat, x, y)
}
